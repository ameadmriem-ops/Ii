package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.annotation.OptIn
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.firebase.messaging.FirebaseMessaging
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.ui.PlayerView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import org.json.JSONObject

data class NotificationNavigationData(
    val page: String = "",
    val firebaseId: String = "",
    val episode: String = "",
    val url: String = "",
    val action: String = "",
    val contentTitle: String = ""
)

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "AdMob"
        private const val FCM_TAG = "FCM_Notification"
        const val DEFAULT_REWARDED_AD_UNIT_ID = "ca-app-pub-2277779478101583/1404104591"
        private const val NOTIFICATION_PERMISSION_REQUEST_CODE = 1002
    }

    private lateinit var webView: WebView
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private lateinit var fullscreenContainer: FrameLayout
    private var adMobBridge: AdMobBridge? = null
    private var isWebViewLoaded: Boolean = false
    private var pendingFcmNotification: NotificationNavigationData? = null

    // Native Media3 ExoPlayer components
    private lateinit var playerContainer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var playerTopBar: LinearLayout
    private lateinit var playerTitleTextView: TextView
    private lateinit var playerProgressBar: ProgressBar
    private lateinit var playerErrorContainer: LinearLayout
    private lateinit var playerErrorTextView: TextView
    private var exoPlayer: ExoPlayer? = null
    private var currentStreamUrl: String? = null
    private var currentStreamTitle: String? = null
    private var isPlayerFullscreen: Boolean = false
    private var playbackTicker: Runnable? = null
    private val playbackHandler = Handler(Looper.getMainLooper())

    private fun startPlaybackTicker() {
        stopPlaybackTicker()
        val runnable = object : Runnable {
            override fun run() {
                if (exoPlayer?.isPlaying == true) {
                    dispatchPlaybackTick(1)
                    playbackHandler.postDelayed(this, 1000)
                } else {
                    stopPlaybackTicker()
                }
            }
        }
        playbackTicker = runnable
        playbackHandler.postDelayed(runnable, 1000)
    }

    private fun stopPlaybackTicker() {
        playbackTicker?.let { playbackHandler.removeCallbacks(it) }
        playbackTicker = null
    }

    private fun dispatchPlaybackTick(seconds: Int) {
        val script = "if(window.onNativeVideoTick){window.onNativeVideoTick($seconds);}"
        webView.post {
            webView.evaluateJavascript(script, null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Notification Channel and FCM
        MyFirebaseMessagingService.createNotificationChannel(this)
        requestNotificationPermission()
        initializeFcm()

        // Initialize Google Mobile Ads SDK (AdMob) once at startup
        Log.d(TAG, "AdMob: Initializing Google Mobile Ads SDK...")
        MobileAds.initialize(this) { initializationStatus ->
            Log.d(TAG, "AdMob: SDK Initialized successfully. Status: ${initializationStatus.adapterStatusMap}")
            // Preload first rewarded ad so it's ready immediately
            adMobBridge?.preloadRewardedAd(DEFAULT_REWARDED_AD_UNIT_ID)
        }

        setupContentView()
        setupBackNavigation()
        handleNotificationIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }

    fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    NOTIFICATION_PERMISSION_REQUEST_CODE
                )
            }
        }
    }

    private fun initializeFcm() {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    Log.d(FCM_TAG, "FCM Device Registration Token: $token")
                    MyFirebaseMessagingService.saveToken(this, token)
                } else {
                    Log.w(FCM_TAG, "Fetching FCM registration token failed", task.exception)
                }
            }
            FirebaseMessaging.getInstance().subscribeToTopic("all_users")
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(FCM_TAG, "Subscribed to topic: all_users")
                    }
                }
            FirebaseMessaging.getInstance().subscribeToTopic("anime_updates")
        } catch (e: Exception) {
            Log.e(FCM_TAG, "Error initializing FCM: ${e.message}", e)
        }
    }

    private fun handleNotificationIntent(intent: Intent?) {
        if (intent == null) return
        val extras = intent.extras ?: return

        val page = extras.getString("fcm_page")
            ?: extras.getString("page")
            ?: extras.getString("target_page")
            ?: extras.getString("screen")
            ?: ""

        val firebaseId = extras.getString("fcm_firebaseId")
            ?: extras.getString("firebaseId")
            ?: extras.getString("id")
            ?: extras.getString("contentId")
            ?: extras.getString("animeId")
            ?: extras.getString("movieId")
            ?: ""

        val episode = extras.getString("fcm_episode")
            ?: extras.getString("episode")
            ?: extras.getString("episodeIndex")
            ?: extras.getString("episodeNumber")
            ?: extras.getString("ep")
            ?: ""

        val url = extras.getString("fcm_url")
            ?: extras.getString("url")
            ?: extras.getString("link")
            ?: ""

        val action = extras.getString("fcm_action")
            ?: extras.getString("action")
            ?: (if (episode.isNotBlank()) "play" else "")

        val contentTitle = extras.getString("contentTitle")
            ?: extras.getString("fcm_contentTitle")
            ?: extras.getString("animeTitle")
            ?: extras.getString("movieTitle")
            ?: extras.getString("name")
            ?: ""

        val hasTarget = page.isNotBlank() || firebaseId.isNotBlank() || episode.isNotBlank() || url.isNotBlank() || contentTitle.isNotBlank()

        if (hasTarget) {
            Log.d(FCM_TAG, "Handling notification intent: page=$page, firebaseId=$firebaseId, episode=$episode, action=$action, contentTitle=$contentTitle, url=$url")
            val navData = NotificationNavigationData(
                page = page,
                firebaseId = firebaseId,
                episode = episode,
                url = url,
                action = action,
                contentTitle = contentTitle
            )
            if (isWebViewLoaded) {
                dispatchFcmNavigation(navData)
            } else {
                pendingFcmNotification = navData
            }
        }
    }

    private fun dispatchFcmNavigation(navData: NotificationNavigationData) {
        val json = JSONObject().apply {
            put("page", navData.page)
            put("firebaseId", navData.firebaseId)
            put("id", navData.firebaseId)
            put("episode", navData.episode)
            put("episodeIndex", navData.episode)
            put("url", navData.url)
            put("action", navData.action)
            put("contentTitle", navData.contentTitle)
        }.toString()

        val script = "if(window.handleFcmNotification){window.handleFcmNotification($json);}"
        Log.d(FCM_TAG, "Dispatching notification navigation to WebView: $json")
        webView.post {
            webView.evaluateJavascript(script, null)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupContentView() {
        val rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)
        }

        fullscreenContainer = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
        }

        setupNativePlayerLayout()

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                useWideViewPort = true
                loadWithOverviewMode = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }

            val cookieManager = android.webkit.CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(this, true)

            // Expose Native AdMob Bridge to JavaScript
            val bridge = AdMobBridge(this@MainActivity, this)
            adMobBridge = bridge
            addJavascriptInterface(bridge, "AndroidBridge")

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    isWebViewLoaded = true
                    pendingFcmNotification?.let { navData ->
                        dispatchFcmNavigation(navData)
                        pendingFcmNotification = null
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    fullscreenContainer.addView(view)
                    fullscreenContainer.visibility = View.VISIBLE
                    webView.visibility = View.GONE
                }

                override fun onHideCustomView() {
                    super.onHideCustomView()
                    if (customView == null) return
                    fullscreenContainer.removeView(customView)
                    fullscreenContainer.visibility = View.GONE
                    webView.visibility = View.VISIBLE
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                }

                override fun getDefaultVideoPoster(): Bitmap? {
                    return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
                }
            }
        }

        rootLayout.addView(webView)
        rootLayout.addView(fullscreenContainer)
        rootLayout.addView(playerContainer)
        setContentView(rootLayout)

        webView.loadUrl("file:///android_asset/index.html")
    }

    @OptIn(UnstableApi::class)
    private fun setupNativePlayerLayout() {
        playerContainer = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
        }

        playerView = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            useController = true
            keepScreenOn = true
            setBackgroundColor(Color.BLACK)
            controllerShowTimeoutMs = 5000
            controllerAutoShow = false
            controllerHideOnTouch = true
            setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
                playerTopBar.visibility = visibility
            })
            setFullscreenButtonClickListener { isFullscreen ->
                toggleFullscreen(isFullscreen)
            }
        }
        playerContainer.addView(playerView)

        val density = resources.displayMetrics.density

        // Top bar overlay for title and back button (integrated with controller)
        playerTopBar = LinearLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP
            }
            orientation = LinearLayout.HORIZONTAL
            setPadding(
                (16 * density).toInt(),
                (36 * density).toInt(),
                (16 * density).toInt(),
                (12 * density).toInt()
            )
            setBackgroundColor(Color.parseColor("#99000000"))
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setOnClickListener {
                playerView.showController()
            }
        }

        // Back button identical to .back-btn used across the rest of the application
        val backButton = TextView(this).apply {
            val padVertical = (8 * density).toInt()
            val padHorizontal = (18 * density).toInt()
            setPadding(padHorizontal, padVertical, padHorizontal, padVertical)

            text = "← رجوع"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false

            val normalBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24 * density
                setColor(Color.parseColor("#181818"))
                setStroke((1 * density).toInt(), Color.parseColor("#333333"))
            }

            val pressedBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24 * density
                setColor(Color.parseColor("#222222"))
                setStroke((1 * density).toInt(), Color.parseColor("#e50914"))
            }

            val stateList = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), pressedBg)
                addState(intArrayOf(android.R.attr.state_focused), pressedBg)
                addState(intArrayOf(), normalBg)
            }

            val rippleColor = ColorStateList.valueOf(Color.parseColor("#33FFFFFF"))
            background = RippleDrawable(rippleColor, stateList, null)

            elevation = 4 * density
            isClickable = true
            isFocusable = true
            contentDescription = "رجوع"

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER_VERTICAL
            }

            setOnClickListener {
                if (isPlayerFullscreen) {
                    exitFullscreen()
                } else {
                    closeNativePlayer()
                }
            }
        }
        playerTopBar.addView(backButton)

        playerTitleTextView = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply {
                marginStart = (14 * density).toInt()
                marginEnd = (14 * density).toInt()
                gravity = Gravity.CENTER_VERTICAL
            }
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            text = "MY MOVIE"
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        playerTopBar.addView(playerTitleTextView)

        playerContainer.addView(playerTopBar)

        // Buffering ProgressBar
        playerProgressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
            }
            visibility = View.GONE
        }
        playerContainer.addView(playerProgressBar)

        // Error overlay
        playerErrorContainer = LinearLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                gravity = Gravity.CENTER
            }
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(Color.parseColor("#EE000000"))
            visibility = View.GONE
        }

        val errorIcon = TextView(this).apply {
            text = "⚠️"
            textSize = 48f
            gravity = Gravity.CENTER
        }
        playerErrorContainer.addView(errorIcon)

        playerErrorTextView = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 20
                bottomMargin = 30
            }
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            text = "تعذر تشغيل هذا البث"
        }
        playerErrorContainer.addView(playerErrorTextView)

        val buttonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val retryButton = Button(this).apply {
            text = "🔄 إعادة المحاولة"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E50914"))
            setOnClickListener {
                currentStreamUrl?.let { url ->
                    playStream(url, currentStreamTitle ?: "")
                }
            }
        }
        buttonsRow.addView(retryButton)

        val closeButton = Button(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = 20
            }
            text = "إغلاق"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#333333"))
            setOnClickListener {
                closeNativePlayer()
            }
        }
        buttonsRow.addView(closeButton)

        playerErrorContainer.addView(buttonsRow)
        playerContainer.addView(playerErrorContainer)
    }

    @OptIn(UnstableApi::class)
    fun playStream(rawUrl: String, title: String) {
        var streamUrl = rawUrl.trim()
        if (streamUrl.isBlank()) {
            Log.e(TAG, "ExoPlayer: playStream called with blank URL")
            return
        }

        // Support Pixeldrain URLs (e.g. https://pixeldrain.com/u/ID or https://pixeldrain.com/api/file/ID)
        val pixeldrainPattern = Regex("""(?i)^(?:https?://)?(?:www\.)?pixeldrain\.com/(?:u|file|api/file)/([a-zA-Z0-9_-]+).*$""")
        val pdMatch = pixeldrainPattern.find(streamUrl)
        if (pdMatch != null) {
            val fileId = pdMatch.groupValues[1]
            streamUrl = "https://pixeldrain.com/api/file/$fileId"
            Log.d(TAG, "Pixeldrain direct video URL resolved: $streamUrl")
        }

        currentStreamUrl = streamUrl
        currentStreamTitle = title

        Log.d(TAG, "ExoPlayer: Playing stream: $streamUrl (Title: $title)")

        runOnUiThread {
            if (isPlayerFullscreen) {
                exitFullscreen()
            }
            playerContainer.visibility = View.VISIBLE
            webView.visibility = View.GONE
            playerTitleTextView.text = title.ifBlank { "MY MOVIE" }
            playerErrorContainer.visibility = View.GONE
            playerProgressBar.visibility = View.VISIBLE
            playerTopBar.visibility = View.GONE
            playerView.hideController()

            try {
                if (exoPlayer == null) {
                    val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                        .setUserAgent("Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                        .setConnectTimeoutMs(20000)
                        .setReadTimeoutMs(20000)
                        .setAllowCrossProtocolRedirects(true)
                        .setKeepPostFor302Redirects(true)
                        .setDefaultRequestProperties(mapOf(
                            "Accept" to "*/*",
                            "Accept-Encoding" to "identity"
                        ))

                    val dataSourceFactory = DefaultDataSource.Factory(this, httpDataSourceFactory)

                    val player = ExoPlayer.Builder(this)
                        .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
                        .setSeekBackIncrementMs(15000)
                        .setSeekForwardIncrementMs(15000)
                        .build()

                    player.addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) {
                            if (isPlaying) {
                                startPlaybackTicker()
                            } else {
                                stopPlaybackTicker()
                            }
                        }

                        override fun onPlaybackStateChanged(playbackState: Int) {
                            when (playbackState) {
                                Player.STATE_BUFFERING -> {
                                    playerProgressBar.visibility = View.VISIBLE
                                }
                                Player.STATE_READY -> {
                                    playerProgressBar.visibility = View.GONE
                                    playerErrorContainer.visibility = View.GONE
                                    playerTopBar.visibility = View.GONE
                                    playerView.hideController()
                                    Log.d(TAG, "ExoPlayer: Playback state READY")
                                }
                                Player.STATE_ENDED -> {
                                    stopPlaybackTicker()
                                    playerProgressBar.visibility = View.GONE
                                }
                                Player.STATE_IDLE -> {
                                    stopPlaybackTicker()
                                }
                            }
                        }

                        override fun onPlayerError(error: PlaybackException) {
                            stopPlaybackTicker()
                            Log.e(TAG, "ExoPlayer: onPlayerError - ${error.errorCodeName} (${error.errorCode}): ${error.message}", error)
                            playerProgressBar.visibility = View.GONE
                            val cause = error.cause
                            val userErrorMessage = when {
                                cause is HttpDataSource.InvalidResponseCodeException -> {
                                    when (cause.responseCode) {
                                        403 -> "خطأ 403: تم رفض الوصول إلى الملف من السيرفر (Forbidden / Access Denied)"
                                        404 -> "خطأ 404: ملف الفيديو غير موجود على السيرفر (File Not Found)"
                                        500 -> "خطأ 500: خطأ داخلي في سيرفر الفيديو (Internal Server Error)"
                                        502, 503 -> "خطأ ${cause.responseCode}: سيرفر الفيديو غير متاح حالياً (Server Unavailable)"
                                        else -> "خطأ HTTP ${cause.responseCode} من سيرفر الفيديو"
                                    }
                                }
                                cause is HttpDataSource.HttpDataSourceException -> {
                                    val msg = cause.message ?: ""
                                    when {
                                        msg.contains("Cleartext", ignoreCase = true) -> {
                                            "خطأ: حركة مرور HTTP غير المشفرة محظورة (Cleartext HTTP blocked)"
                                        }
                                        cause.cause is java.net.SocketTimeoutException -> {
                                            "مشكلة اتصال بالإنترنت: انتهت مهلة الاتصال بالسيرفر (Connection Timeout)"
                                        }
                                        cause.cause is java.net.ConnectException -> {
                                            "مشكلة اتصال بالإنترنت: فشل الاتصال بالسيرفر (Connection Failed)"
                                        }
                                        cause.cause is java.net.UnknownHostException -> {
                                            "تعذر الوصول لعنوان السيرفر أو الرابط غير صالح (Unknown Host / Invalid URL)"
                                        }
                                        else -> {
                                            "فشل الاتصال بسيرفر الفيديو: ${cause.message ?: "يرجى التحقق من توفر الملف والإنترنت"}"
                                        }
                                    }
                                }
                                error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                                error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> {
                                    "نوع صيغة ملف الفيديو غير مدعوم من المشغل (Unsupported Video Format)"
                                }
                                error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                                error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> {
                                    "صيغة ملف الفيديو تالفة أو غير صالحة (Malformed Media File)"
                                }
                                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> {
                                    "مشكلة اتصال بالإنترنت: انتهت مهلة الاتصال بالسيرفر (Timeout)"
                                }
                                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> {
                                    "مشكلة اتصال بالإنترنت: فشل الاتصال بشبكة الفيديو (Connection Failed)"
                                }
                                cause is java.io.IOException && cause.message?.contains("Cleartext", ignoreCase = true) == true -> {
                                    "حركة مرور HTTP محظورة (Cleartext HTTP blocked)"
                                }
                                else -> {
                                    "تعذر تشغيل هذا الملف: ${error.localizedMessage ?: "تأكد من عمل الرابط والسيرفر"}"
                                }
                            }
                            playerErrorTextView.text = userErrorMessage
                            playerErrorContainer.visibility = View.VISIBLE
                        }
                    })

                    playerView.player = player
                    exoPlayer = player
                }

                // Build HLS or Progressive MediaSource
                val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                    .setUserAgent("Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                    .setConnectTimeoutMs(20000)
                    .setReadTimeoutMs(20000)
                    .setAllowCrossProtocolRedirects(true)
                    .setKeepPostFor302Redirects(true)
                    .setDefaultRequestProperties(mapOf(
                        "Accept" to "*/*",
                        "Accept-Encoding" to "identity"
                    ))

                val dataSourceFactory = DefaultDataSource.Factory(this, httpDataSourceFactory)
                val hlsMediaSourceFactory = HlsMediaSource.Factory(dataSourceFactory)
                    .setAllowChunklessPreparation(true)

                val uri = Uri.parse(streamUrl)
                val isHls = streamUrl.contains(".m3u8", ignoreCase = true) ||
                        streamUrl.contains("application/vnd.apple.mpegurl", ignoreCase = true) ||
                        streamUrl.contains("application/x-mpegURL", ignoreCase = true) ||
                        streamUrl.contains("application/x-mpegurl", ignoreCase = true)

                val mediaItemBuilder = MediaItem.Builder().setUri(uri)
                if (isHls) {
                    mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
                }
                val mediaItem = mediaItemBuilder.build()

                val extractorsFactory = DefaultExtractorsFactory()
                    .setConstantBitrateSeekingEnabled(true)

                val mediaSource = if (isHls) {
                    hlsMediaSourceFactory.createMediaSource(mediaItem)
                } else {
                    // For direct video files (MP4, MKV, WebM, Pixeldrain API, etc.)
                    ProgressiveMediaSource.Factory(dataSourceFactory, extractorsFactory)
                        .createMediaSource(mediaItem)
                }

                exoPlayer?.apply {
                    stop()
                    setMediaSource(mediaSource)
                    prepare()
                    playWhenReady = true
                }
                playerTopBar.visibility = View.GONE
                playerView.hideController()
            } catch (e: Exception) {
                Log.e(TAG, "Error starting ExoPlayer stream: ${e.message}", e)
                playerProgressBar.visibility = View.GONE
                playerErrorTextView.text = "خطأ في تهيئة المشغل: ${e.message}"
                playerErrorContainer.visibility = View.VISIBLE
            }
        }
    }

    fun closeNativePlayer() {
        runOnUiThread {
            stopPlaybackTicker()
            if (isPlayerFullscreen) {
                exitFullscreen()
            }
            exoPlayer?.stop()
            playerView.hideController()
            playerTopBar.visibility = View.GONE
            playerContainer.visibility = View.GONE
            webView.visibility = View.VISIBLE
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (playerContainer.visibility == View.VISIBLE) {
                    if (isPlayerFullscreen) {
                        exitFullscreen()
                    } else {
                        closeNativePlayer()
                    }
                } else if (customView != null) {
                    webView.webChromeClient?.onHideCustomView()
                } else {
                    webView.evaluateJavascript("if(window.historyStack && window.historyStack.length > 0){ window.goBack(); true; } else { false; }") { result ->
                        if (result == "false" || result == null) {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        }
                    }
                }
            }
        })
    }

    private fun enterFullscreen() {
        if (isPlayerFullscreen) return
        isPlayerFullscreen = true
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        hideSystemBars()
        val density = resources.displayMetrics.density
        playerTopBar.setPadding(
            (16 * density).toInt(),
            (14 * density).toInt(),
            (16 * density).toInt(),
            (12 * density).toInt()
        )
        playerView.showController()
    }

    private fun exitFullscreen() {
        if (!isPlayerFullscreen) return
        isPlayerFullscreen = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        showSystemBars()
        val density = resources.displayMetrics.density
        playerTopBar.setPadding(
            (16 * density).toInt(),
            (36 * density).toInt(),
            (16 * density).toInt(),
            (12 * density).toInt()
        )
        playerView.showController()
    }

    private fun toggleFullscreen(toFullscreen: Boolean? = null) {
        val target = toFullscreen ?: !isPlayerFullscreen
        if (target) {
            enterFullscreen()
        } else {
            exitFullscreen()
        }
    }

    private fun hideSystemBars() {
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (playerContainer.visibility == View.VISIBLE) {
            val isLandscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
            if (isLandscape && !isPlayerFullscreen) {
                isPlayerFullscreen = true
                hideSystemBars()
            } else if (!isLandscape && isPlayerFullscreen) {
                isPlayerFullscreen = false
                showSystemBars()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        stopPlaybackTicker()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        stopPlaybackTicker()
        if (isPlayerFullscreen) {
            exitFullscreen()
        }
        exoPlayer?.release()
        exoPlayer = null
        webView.destroy()
        super.onDestroy()
    }

    /**
     * Native AdMob and Video Player bridge exposed to JavaScript
     */
    class AdMobBridge(private val activity: MainActivity, private val webView: WebView) {
        private val mainHandler = Handler(Looper.getMainLooper())
        private var isLoading = false
        private var hasHandled = false
        private var timeoutRunnable: Runnable? = null

        private var preloadedRewardedAd: RewardedAd? = null
        private var isPreloading = false

        @JavascriptInterface
        fun isAvailable(): Boolean = true

        @JavascriptInterface
        fun isNativePlayerAvailable(): Boolean = true

        @JavascriptInterface
        fun playStream(url: String, title: String) {
            activity.playStream(url, title)
        }

        @JavascriptInterface
        fun closePlayer() {
            activity.closeNativePlayer()
        }

        @JavascriptInterface
        fun getSavedUserRole(): String {
            val prefs = activity.getSharedPreferences("app_auth_prefs", Activity.MODE_PRIVATE)
            return prefs.getString("user_role", "") ?: ""
        }

        @JavascriptInterface
        fun saveUserRole(role: String) {
            val prefs = activity.getSharedPreferences("app_auth_prefs", Activity.MODE_PRIVATE)
            prefs.edit().putString("user_role", role.trim().uppercase()).apply()
        }

        @JavascriptInterface
        fun clearUserRole() {
            val prefs = activity.getSharedPreferences("app_auth_prefs", Activity.MODE_PRIVATE)
            prefs.edit().remove("user_role").apply()
        }

        @JavascriptInterface
        fun openExternalUrl(rawUrl: String): Boolean {
            if (rawUrl.isBlank()) return false
            var url = rawUrl.trim()
            if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                url = "https://$url"
            }

            return try {
                val uri = Uri.parse(url)
                val isYouTube = url.contains("youtube.com", ignoreCase = true) || url.contains("youtu.be", ignoreCase = true)

                activity.runOnUiThread {
                    try {
                        if (isYouTube) {
                            // Try opening with YouTube app first
                            val youtubeIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                                setPackage("com.google.android.youtube")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try {
                                activity.startActivity(youtubeIntent)
                                Log.d(TAG, "External Link: Successfully opened YouTube app for URL: $url")
                                return@runOnUiThread
                            } catch (e: Exception) {
                                Log.d(TAG, "External Link: YouTube app not available, falling back to browser.")
                            }
                        }

                        // Open with default browser or appropriate app on device
                        val genericIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        activity.startActivity(genericIntent)
                        Log.d(TAG, "External Link: Successfully launched intent for URL: $url")
                    } catch (e: Exception) {
                        Log.e(TAG, "External Link: Error launching intent: ${e.message}", e)
                    }
                }
                true
            } catch (e: Exception) {
                Log.e(TAG, "External Link: Failed to parse URL: $rawUrl", e)
                false
            }
        }

        @JavascriptInterface
        fun getFcmToken(): String {
            return MyFirebaseMessagingService.getSavedToken(activity)
        }

        @JavascriptInterface
        fun copyFcmTokenToClipboard() {
            activity.runOnUiThread {
                val token = MyFirebaseMessagingService.getSavedToken(activity)
                if (token.isNotBlank()) {
                    val clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("FCM Token", token)
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(activity, "تم نسخ رمز FCM للجهاز بنجاح", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(activity, "جاري تهيئة رمز FCM، يرجى المحاولة بعد لحظات", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            activity.runOnUiThread {
                activity.requestNotificationPermission()
            }
        }

        @JavascriptInterface
        fun triggerConfiguredNotification() {
            activity.runOnUiThread {
                NotificationConfig.sendConfiguredNotification(activity)
            }
        }

        @JavascriptInterface
        fun triggerCustomNotification(
            title: String,
            message: String,
            page: String,
            contentId: String,
            episode: String,
            imageUrl: String,
            action: String,
            contentTitle: String
        ) {
            activity.runOnUiThread {
                NotificationConfig.sendCustomNotification(
                    context = activity,
                    title = title,
                    message = message,
                    page = page,
                    contentId = contentId,
                    episode = episode,
                    url = "",
                    action = action,
                    imageUrl = imageUrl,
                    contentTitle = contentTitle
                )
            }
        }

        fun preloadRewardedAd(adUnitId: String) {
            val targetUnitId = adUnitId.ifBlank { DEFAULT_REWARDED_AD_UNIT_ID }
            activity.runOnUiThread {
                if (preloadedRewardedAd != null || isPreloading) {
                    Log.d(TAG, "AdMob [Preload]: Rewarded Ad is already loaded or preloading in progress.")
                    return@runOnUiThread
                }

                isPreloading = true
                Log.d(TAG, "AdMob [Preload]: بدأ التحميل (Started preloading) with Ad Unit ID: $targetUnitId")

                val adRequest = AdRequest.Builder().build()
                RewardedAd.load(activity, targetUnitId, adRequest, object : RewardedAdLoadCallback() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        activity.runOnUiThread {
                            isPreloading = false
                            preloadedRewardedAd = null
                            Log.e(
                                TAG,
                                "AdMob [Preload]: فشل التحميل (Failed to load) - Code: ${loadAdError.code}, Message: ${loadAdError.message}, Domain: ${loadAdError.domain}"
                            )
                        }
                    }

                    override fun onAdLoaded(rewardedAd: RewardedAd) {
                        activity.runOnUiThread {
                            isPreloading = false
                            preloadedRewardedAd = rewardedAd
                            Log.d(TAG, "AdMob [Preload]: تم تحميله بنجاح (Loaded successfully) - Ad is cached and ready!")
                        }
                    }
                })
            }
        }

        @JavascriptInterface
        fun loadAndShowRewardedAd(adUnitId: String, timeoutMs: Long) {
            val targetUnitId = adUnitId.ifBlank { DEFAULT_REWARDED_AD_UNIT_ID }
            activity.runOnUiThread {
                if (isLoading) {
                    Log.w(TAG, "AdMob: loadAndShowRewardedAd called while another ad is already being processed.")
                    return@runOnUiThread
                }
                isLoading = true
                hasHandled = false

                // If preloaded ad is already available, show it immediately!
                val cachedAd = preloadedRewardedAd
                if (cachedAd != null) {
                    Log.d(TAG, "AdMob: تم العثور على إعلان مسبق التحميل، جاري العرض فوراً (Using preloaded ad directly)...")
                    preloadedRewardedAd = null
                    showLoadedAd(cachedAd, targetUnitId)
                    return@runOnUiThread
                }

                // If not preloaded, initiate load with safety timeout
                Log.d(TAG, "AdMob: بدأ التحميل (Started loading ad) with Ad Unit ID: $targetUnitId")
                timeoutRunnable?.let { mainHandler.removeCallbacks(it) }
                val timer = Runnable {
                    if (!hasHandled) {
                        hasHandled = true
                        isLoading = false
                        Log.w(TAG, "AdMob: انتهت مهلة البحث عن الإعلان (Ad load timed out after ${timeoutMs}ms)")
                        notifyJsResult(false, "timeout")
                    }
                }
                timeoutRunnable = timer
                mainHandler.postDelayed(timer, timeoutMs)

                val adRequest = AdRequest.Builder().build()
                RewardedAd.load(activity, targetUnitId, adRequest, object : RewardedAdLoadCallback() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        activity.runOnUiThread {
                            if (!hasHandled) {
                                hasHandled = true
                                timeoutRunnable?.let { mainHandler.removeCallbacks(it) }
                                isLoading = false
                                Log.e(
                                    TAG,
                                    "AdMob: فشل التحميل (Failed to load) - Code: ${loadAdError.code}, Message: ${loadAdError.message}, Domain: ${loadAdError.domain}"
                                )
                                notifyJsResult(false, "load_failed")
                            }
                        }
                    }

                    override fun onAdLoaded(rewardedAd: RewardedAd) {
                        activity.runOnUiThread {
                            if (hasHandled) {
                                Log.w(TAG, "AdMob: تم تحميل الإعلان بعد انتهاء المهلة، سيتم حفظه للإعلان القادم.")
                                preloadedRewardedAd = rewardedAd
                                return@runOnUiThread
                            }
                            timeoutRunnable?.let { mainHandler.removeCallbacks(it) }
                            Log.d(TAG, "AdMob: تم تحميل الإعلان بنجاح (Ad loaded successfully). جاري عرضه...")
                            showLoadedAd(rewardedAd, targetUnitId)
                        }
                    }
                })
            }
        }

        private fun showLoadedAd(rewardedAd: RewardedAd, adUnitId: String) {
            var userEarnedReward = false

            rewardedAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "AdMob: تم عرضه بنجاح على الشاشة (Ad showed full screen content / Impression)")
                }

                override fun onAdDismissedFullScreenContent() {
                    activity.runOnUiThread {
                        isLoading = false
                        Log.d(TAG, "AdMob: تم إغلاقه (Ad dismissed by user). العودة للتطبيق بشكل طبيعي.")
                        if (!hasHandled) {
                            hasHandled = true
                            notifyJsResult(userEarnedReward, if (userEarnedReward) "watched" else "dismissed_early")
                        }
                        // Preload the next rewarded ad in background
                        preloadRewardedAd(adUnitId)
                    }
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    activity.runOnUiThread {
                        isLoading = false
                        Log.e(
                            TAG,
                            "AdMob: فشل عرض الإعلان (Failed to show full screen content) - Code: ${adError.code}, Message: ${adError.message}"
                        )
                        if (!hasHandled) {
                            hasHandled = true
                            notifyJsResult(false, "failed_to_show")
                        }
                        // Preload the next rewarded ad in background
                        preloadRewardedAd(adUnitId)
                    }
                }
            }

            try {
                rewardedAd.show(activity) { rewardItem ->
                    userEarnedReward = true
                    Log.d(
                        TAG,
                        "AdMob: تم استحقاق المكافأة للمستخدم (User earned reward) - Type: ${rewardItem.type}, Amount: ${rewardItem.amount}"
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "AdMob: Exception while showing rewarded ad: ${e.message}", e)
                isLoading = false
                if (!hasHandled) {
                    hasHandled = true
                    notifyJsResult(false, "exception")
                }
            }
        }

        private fun notifyJsResult(success: Boolean, reason: String) {
            val script = "if(window.onAdMobRewardResult){window.onAdMobRewardResult($success, '$reason');}"
            webView.evaluateJavascript(script, null)
        }
    }
}
